package Classes.Virus;

/**
* Classe Anti-Virus é do problema livre, onde Possui o progresso da cura sendo relacionado com as verificações citadas abaixo. <br>
* <br> 1. A cura será inicializada quando tiver o primeiro {@link Classes.Humanos.Zumbi} no mundo. {@link #IniciarCura()}
* <br> 2. Quanto mais zumbis mais rapido a cura sera feita -> {@link #AjudarProgressoDaCura()}. Todas as <b> {@link Classes.Humanos.PessoaSaudavel} que estiverem no hospital </b> irá contribuir para a cura.
*/
public class AntiVirus {

    private double ProgressoDaCura = 0;
    private final double Multiplicador = 0.005;
    private final int CorVacinado = 7;
    private int Zumbis = 0;

    public void getQuantZumbis(int Zumbis) {
        this.Zumbis = Zumbis;
    }

    //Essa parte onde é Relacionada, ao que foi dito na descrição da classe.
    public void AjudarProgressoDaCura() {
        ProgressoDaCura = Math.min(ProgressoDaCura + (Zumbis * Multiplicador), 100);
    }

    public boolean IniciarCura() {
        return Zumbis > 0;
    }

    
    public boolean CuraTerminada() {
        return ProgressoDaCura >= 100;
    }

    public int Vacina() {
        return CorVacinado;
    }

    public double getProgressoDaCura() {
        return ProgressoDaCura;
    }

}
