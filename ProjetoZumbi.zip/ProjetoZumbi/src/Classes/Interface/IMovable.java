package Classes.Interface;

/**
* Classe IMovable é uma interface da movimentação da {@link Classes.Humanos}. 
* <br>
* Onde: <br>
* <br> 0 = Ficar parado (Extra)
* <br> 1 = Mover para Cima
* <br> 2 = Mover para Baixo
* <br> 3 = Mover para Direita
* <br> 4 = Mover para Esquerda
*/
public interface IMovable {
    void Mover(int Imove);
}
