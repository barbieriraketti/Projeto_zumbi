package Classes;

import java.util.Locale;

import Classes.Estrutura.Mundo;

/**
* Função "Main" (entry point), onde o programa será inicializado.
* <br><br>
* Resumo do jogo: <br>
*<br> 0.  O jogo Possui 102 pessoas onde 2 serão as Pessoas Doentes, em um Mapa[Variavel Grade] 30 por 90. (ambos podem ser alterado case deseje)
*<br> 1.  O jogo irá Gerar aleatóriamente a posição das Pessoas e dos Hospitais.
*<br> 2.  Se uma Pessoa Saudavel enconsta na Pessoa Doente, ela passa a ser doente.
*<br> 3.  Pessoas Doentes podem ser curadas dentro de 15 segundos se entrarem no hospital.
*<br> 4.  Caso uma pessoa fique doente por mais de 15 segundos ela vira Zumbi.
*<br> 5.  Zumbis não podem se curar se entrarem no hospital.
*<br> 6.  Quando o jogo tem o primeiro Zumbi no mundo, começa o processo de Cura
*<br> 7.  Esse processo só pode ser feito por Pessoas Saudaveis caso elas estajam dentro do Hospital.
*<br> 8.  A cura será acelerada de acordo com a quantidade de zumbis no mundo.
*<br> 9.  Quando a cura chega em 100%, Qualquer pessoa Saudavel que entrar ou estiver no hospital irá receber a Vacina "AntiVirus", e sera marcado como Curado.
*<br> 10. Pessoas curadas não são afetadas por Zumbis ou Pessoas Doentes.
*<br> 11. Caso um Zumbi enconste em uma Pessoa Curada, ela vira uma Pessoa Doente e tem 15 segundos para entrar no hospital e ser Curada tambem.
*<br> 12. Caso contrario essa pessoa doente morre, ja que ela não pode virar Zumbi novamente.
*<br> 13. A humanidade vence no momento que a cura é feita e possui ao menos 1 pessoa curada.
* <br><br>
* Devido algumas limitações e a natureza do Math.random, é possivel ter cenários extremamente raros descritos abaixo. (Os 2 primeiros finais é possivel contornar mas, por ser rarissimo achei legal deixar, como sendo um final feliz!)
* <br><br>
* Todos os Possiveis finais de jogo: <br>
* <br> 0. [IMPOSSIVEL] O programa crashar kkkkkkkkkkk (é serio.)
* <br> 1. [EXTREMAMENTE RARO] As 2 Pessoas doentes são geradas dentro do hospital e com isso, será curada e o jogo acaba.
* <br> 2. [EXTREMAMENTE RARO] As 2 Pessoas doentes são geradas fora do hospital, mas em menos de 15 segundos elas entram no hospital sem infectar ninguem e o jogo acaba.
* <br> 3. [MUITO RARO]        O processo de cura não é completado a tempo e todo mundo é infectado.
* <br> 3. [MUITO COMUM]       O processo de cura é finalizado.
* 

* <br><br>
* Objetivo: Cria o objeto da Classe {@link Classes.Estrutura.Mundo} e atualiza o mundo a cada 300 milisegundos (ms)
* <br><br>
* Classes importadas: {@link Classes.Estrutura.Mundo}
* <br><br>
* Metodos utilizados:
* <br> {@link Classes.Estrutura.Mundo#getNumeroDeSaudaveis()}
* <br> {@link Classes.Estrutura.Mundo#getNumeroDeDoentes()}
* <br> {@link Classes.Estrutura.Mundo#getNumeroDeZumbis()}
* <br> {@link Classes.Estrutura.Mundo#getCuraMundialTerminada()}
* <br> {@link Classes.Estrutura.Mundo#getCuradosMundial()}
* <br> {@link Classes.Estrutura.Mundo#getNumeroDeZumbisCurados()}
* <br> {@link Classes.Estrutura.Mundo#getNumeroDeZumbisMortos()}
* <br> {@link Classes.Estrutura.Mundo#getProgressoDaCuraMundial()}
* <br> {@link Classes.Estrutura.Mundo#atualizaMundo()}
* <br> {@link Classes.Estrutura.Mundo#desenhaMundo()}
*/
public class Main {

    public static void main(String[] args) {

        int Grade[] = {30, 90}; //Linha, Coluna

        Mundo m = new Mundo(Grade); //Pode Tamanho Customizado ou nao. (overload)

        Boolean Lmao = true;
        while(Lmao){
            int PessoasSaudaveis = m.getNumeroDeSaudaveis();
            int PessoasDoentes = m.getNumeroDeDoentes();
            int PessoasZumbi = m.getNumeroDeZumbis();
            System.out.printf("\n\n\033[44m \033[0m Saudaveis: %03d \t \033[43m \033[0m Doentes: %03d \t \033[42m \033[0m Zumbis: %03d\n", PessoasSaudaveis, PessoasDoentes, PessoasZumbi);

            if (m.getCuraMundialTerminada()) {
               System.out.printf("\033[46m \033[0m Curados: %03d \n", m.getCuradosMundial());
               System.out.println("Total de Zumbis Curados: " + m.getNumeroDeZumbisCurados());
               System.out.println("Total de Zumbis Mortos: " + m.getNumeroDeZumbisMortos());
            } else {
                System.out.printf("%s", String.format(Locale.US, "\0[!] Progresso da Cura: %.2f%% \n", m.getProgressoDaCuraMundial()));
            }

            System.out.printf("Total de pessoas: %03d\n", PessoasSaudaveis + PessoasDoentes + PessoasZumbi);
            m.atualizaMundo();
            m.desenhaMundo();
            //Lmao = false;
        try{
            Thread.sleep(300);
        }
        catch(Exception e){
                System.out.println();
            }
        }
    }
}
