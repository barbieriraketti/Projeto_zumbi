package Classes.Humanos;

import java.util.Timer;
import java.util.TimerTask;

import Classes.Interface.IMovable;
import Classes.Virus.Virus;

/**
* Classe Pessoa Doente verifica o tempo até a pessoa tornar zumbi. Esse tempo é definido pela {@link Classes.Virus.Virus}
*/
public class PessoaDoente extends Pessoa implements IMovable{

    boolean IsZumbi = false; //Se for true, o tempo dele acabou...
    boolean JaFoiZumbi = false;

    private Virus VirusNaPessoa;

    private Timer Contador = new Timer();

    public PessoaDoente(int x, int y, int cor, Virus VirusNaPessoa) {
        super(x, y, cor);
        this.VirusNaPessoa = VirusNaPessoa;
        AtivarZumbiTimer();
    }

    protected void AtivarZumbiTimer() {
        Contador.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                IsZumbi = true;
                Contador.cancel();
            }
        }, VirusNaPessoa.getZumbiCount() * 1000, 1);
    }


    public boolean getIsZumbi() {
        return IsZumbi;
    }

    public void setJaFoiZumbi(boolean jaFoiZumbi) {
        JaFoiZumbi = jaFoiZumbi;
    }

    public boolean getJaFoiZumbi() {
        return JaFoiZumbi;
    }

    @Override
    public void Mover(int Imove) {
        if (Imove == 1) {

            setY(getY() - 1);
        } else if (Imove == 2) {

            setY(getY() + 1);
        } else if (Imove == 3) {

            setX(getX() + 1);
        } else if (Imove == 4) {

            setX(getX() - 1);
        }
    }         

}
