package Classes.Humanos;

/**
* Classe Pessoa Contem a Cordenada e a Cor que será usado quando for Herdado de {@link PessoaDoente}, {@link PessoaSaudavel} e {@link Zumbi}.
*/
public class Pessoa {
    int x, y, cor;

    public Pessoa(int x, int y, int cor) {
        this.x = x;
        this.y = y;
        this.cor = cor;
    } 

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getCor() {
        return cor;
    }

    public void setCor(int cor) {
        this.cor = cor;
    }
}
