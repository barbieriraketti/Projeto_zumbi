package Classes.Virus;

/**
* Classe Virus Possui o tempo que o virus precisa ficar na {@link Classes.Humanos.PessoaDoente} para virar {@link Classes.Humanos.Zumbi}.
*/
public class Virus {
    int TempoNecessarioParaVirarZumbi = 15; //Segundos
    int CorZumbi = 4;

    public int getZumbiCount() {
        return TempoNecessarioParaVirarZumbi;
    }
}
