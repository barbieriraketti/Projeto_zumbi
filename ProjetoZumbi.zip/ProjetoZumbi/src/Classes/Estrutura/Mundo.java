package Classes.Estrutura;

import java.util.ArrayList;

/*
DEFAULT  = \033[49m  -> Parede
AZUL     = \033[44m  -> Saudavel
AMARELO  = \033[43m  -> Doente
VERDE    = \033[42m  -> Zumbi
VERMELHO = \033[41m  -> Hospital
BRANCO   = \033[47m  -> Hospial-Cruz
*/


import java.util.Random;

import Classes.Humanos.PessoaDoente;
import Classes.Humanos.PessoaSaudavel;
import Classes.Humanos.Zumbi;
import Classes.Virus.AntiVirus;
import Classes.Virus.Virus;

/**
* Classe Mundo, onde todas as interações serão feitas.

* <br><br>
* Objetivo: Qualquer tipo de interação será executada nessa Classe. <br>
* Para mais detalhes sobre as interações olhe a descrição dos <b> Métodos Interacional </b>.
* <br><br>
* Classes Principais:
* <br> {@link Classes.Humanos}
* <br> {@link Classes.Estrutura.Hospital}
* <br> {@link Classes.Virus}
* <br><br>
* Métodos Principais:
* <br>
* {@link #GerarMapa()}
* <br>
* {@link #GerarPessoas()}
* <br>
* {@link #GerarHospital()}
* <br>
* {@link #atualizaMundo()}
* <br><br>
* Métodos Interacional:
* <br> {@link #AtualizaPessoasSaudaveis()}
* <br> {@link #AtualizaPessoasDoentes()}
* <br> {@link #AtualizaZumbis()}
* <br> {@link #AtualizaZumbis()}
* <br> {@link #AtualizaHospital()}
* <br><br>
* Métodos do Problema livre:
* <br>
* {@link #getProgressoDaCuraMundial()}
* <br>
* {@link #getCuraMundialTerminada()}
* <br>
* {@link #getCuradosMundial()}
*/

public class Mundo {
    protected int MapaLinha, MapaColuna; 
    public int[][] MapaMundo;

    protected int MaximoDePessoas = 102;

    protected int NumeroDeSaudaveis = 0;
    protected int NumeroDeDoentes = 0;
    protected int NumeroDeZumbis = 0;
    protected int NumeroDeZumbisMortos = 0;
    protected int NumeroDeZumbisCurados = 0;
    //Default
    public Mundo() {
        this.MapaLinha = 30;
        this.MapaColuna = 90;
        CriarMundo();
    }

    //CustomSize
    public Mundo(int[] Grade) {
        this.MapaLinha = Grade[0];
        this.MapaColuna = Grade[1];
        CriarMundo();
    }

    ArrayList <PessoaSaudavel>  PessoasSaudaveis = new ArrayList<>();
    ArrayList <PessoaDoente>    PessoasDoentes   = new ArrayList<>();
    ArrayList <Zumbi>               Zumbis       = new ArrayList<>();
    ArrayList <Hospital>           Hospitais     = new ArrayList<>();

    //Misc
    Virus VirusNoMundo = new Virus();
    AntiVirus antiVirus = new AntiVirus();
    //

    /**
     * <p>Cria uma Array 2D (X, Y) que será o mundo do jogo, e verifica Se X ou Y é uma parede</p>
     */
    protected void GerarMapa() {
        MapaMundo = new int[MapaLinha][MapaColuna];

        for (int i = 0; i < MapaLinha; i++) {
            for (int j = 0; j < MapaColuna; j++) {
                boolean IsParede = (i == 0 || i == (MapaLinha -1)) || (j == 0 || j == (MapaColuna-1));

                MapaMundo[i][j] = IsParede ? 1 : 0;
            }
        }
    }

    /**
     * <p>Cria uma quantidade definida pelo código ou usa o <b> valor padrao de 102 pessoas </b>. Sendo 2 delas Instanciadas como {@link Classes.Humanos.PessoaDoente}.</p>
     */
    protected void GerarPessoas() {
        //! Gerar Pessoas
        for (int i = 1; i <= MaximoDePessoas; i++) {

            Boolean SetDoente = i > MaximoDePessoas-2;
            
            Random Rand = new Random();

            int PosX = Rand.nextInt(MapaColuna-2) + 1;
            int PosY = Rand.nextInt(MapaLinha-2) + 1;

            if (SetDoente) {
                PessoasDoentes.add(new PessoaDoente(PosX, PosY, 3, VirusNoMundo));
            } else {
                PessoasSaudaveis.add(new PessoaSaudavel(PosX, PosY, 2));
            }

            MapaMundo[PosY][PosX] = SetDoente ? 3 : 2;
        }
    }

    /**
     * <p>Cria 3 Hospitais em posições aleatórias. Para mais informação sobre o algoritimo veja: {@link Classes.Estrutura.Hospital} </p>
     */    
    protected void GerarHospital() {
        //! Gerar Hospital
        for (int i = 1; i <= 3; i++) {
            Hospitais.add(new Hospital());
        }
        Hospitais.forEach(Objeto -> {
            int[] SafePos = Objeto.CriarHospital(MapaMundo); //Retorna Posição Correta para Preencher o Hospital.
            
            System.out.print(SafePos[0] + " - " + SafePos[1] + "\n");

            int[][] GetHospital = Objeto.getEstruturaHospital();

            int SizeHPLinha = GetHospital.length;
            int SizeHPColuna = GetHospital[0].length;


            //Transcript {X,Y} > {X2, Y2}
            for (int i = 0; i < SizeHPLinha; i++) {
                for (int j = 0; j < SizeHPColuna; j++) {
                    int TransX = SafePos[0] + i;
                    int TransY = SafePos[1] + j;

                    MapaMundo[TransX][TransY] = GetHospital[i][j];
                }
            }
        });
    }

    /**
     * <p>Metodo entry point da classe onde será chamado todos os métodos para executar o jogo</p>
     */
    protected void CriarMundo() {
        GerarMapa();
        GerarPessoas();
        GerarHospital();
    }

    /**
     * <p>Metodo onde irá fazer o clamp das cordenadas inseguras para a Array 2D do mundo</p>
     * @param UnsafeX Cordenada X não confiavel para Verificar no Mapa.
     * @param UnsafeY Cordenada Y não confiavel para Verificar no Mapa.
     * @return Retorna 3 Objetos em Array: 
     * <br>
     * Boolean: Foi necessário dar Clamp em X ou Y?
     * <br>
     * int: Cordenada X Segura.
     * <br>
     * int: Cordenada Y Segura.
     */    
    protected Object[] ClampBounds(int UnsafeX, int UnsafeY ) {
        //Out of bounds
        Boolean X_OFB_P = UnsafeX >= (MapaColuna-1);
        Boolean Y_OFB_P = UnsafeY >= (MapaLinha-1);

        Boolean X_OFB_N = UnsafeX < 1;
        Boolean Y_OFB_N = UnsafeY < 1;

        int ClampX = X_OFB_P ? 1 : (X_OFB_N ? MapaColuna-2 : UnsafeX);
        int ClampY = Y_OFB_P ? 1 : (Y_OFB_N ? MapaLinha-2 : UnsafeY);     

        Object[] Retornos = new Object[3];
        Retornos[0] = (X_OFB_P || Y_OFB_P || X_OFB_N || Y_OFB_N);
        Retornos[1] = ClampX;
        Retornos[2] = ClampY;
        return Retornos;
    }

    /**
     * <p>Método onde {@link Classes.Humanos.Zumbi} é atualizado suas interações com o mundo</p>
     */    
    protected void AtualizaZumbis() {
        Zumbis.forEach(Objeto -> {
            int OldPX = Objeto.getX();
            int OldPY = Objeto.getY();

            MapaMundo[OldPY][OldPX] = 0;


            int MoveRandom = new Random().nextInt((4 - 1) + 1) + 1;

            Objeto.Mover(MoveRandom);

            int NewPX = Objeto.getX();
            int NewPY = Objeto.getY();

            //Out of bounds
            Object[] GetClamps = ClampBounds(NewPX, NewPY);

            int ClampX = (int)GetClamps[1];
            int ClampY = (int)GetClamps[2];

            if ((boolean)GetClamps[0]) {
                Objeto.setX(ClampX);
                Objeto.setY(ClampY);                
            }

            int[][] GetVacinado = Objeto.PertoDeVacinado();

            for (int i = 0; i < GetVacinado.length; i++) {
                int CurrX = GetVacinado[i][0];
                int CurrY = GetVacinado[i][1];

                //MapaMundo[CurrX][CurrY] = 5;

                int GetNum = MapaMundo[CurrY][CurrX];

                //Zumbi -> PessoaDoente Chance de Conversao 20% caso contrario ele morre. XD
                if (GetNum == 7) {
                    int ChanceDeSucesso = new Random().nextInt(100) + 1;
                    if (ChanceDeSucesso >= 80) {
                        NumeroDeZumbisCurados += 1;

                        PessoaDoente PSDoenteCustom = new PessoaDoente(ClampX, ClampY, 3, VirusNoMundo);
                        PSDoenteCustom.setJaFoiZumbi(true);

                        PessoasDoentes.add(PSDoenteCustom);
                        Objeto.setCor(3); //Sera usado pra deletar o objeto e criar um novo.
                    } else {
                        NumeroDeZumbisMortos += 1;
                        Objeto.setCor(0); //RIP.
                    }
                    break;
                }
            }            
                      
            MapaMundo[ClampY][ClampX] = Objeto.getCor();
        }); 
    }


    /**
     * <p>Método onde {@link Classes.Humanos.PessoaSaudavel} é atualizado suas interações com o mundo</p>
     */    
    protected void AtualizaPessoasSaudaveis() {
        PessoasSaudaveis.forEach(Objeto -> {
            int OldPX = Objeto.getX();
            int OldPY = Objeto.getY();

            MapaMundo[OldPY][OldPX] = 0;

            //Imunidade ativada caso esteja vacinado
            if (!Objeto.getIsVacinado()) {
                int[][] GetInfected = Objeto.PertoDeCotaminado();

                for (int i = 0; i < GetInfected.length; i++) {
                    int CurrX = GetInfected[i][0];
                    int CurrY = GetInfected[i][1];

                    //MapaMundo[CurrX][CurrY] = 5;

                    int GetNum = MapaMundo[CurrY][CurrX];

                    //PessoaSaudavel -> PessoaDoente
                    if (GetNum == 3 || GetNum == 4) {
                        PessoasDoentes.add(new PessoaDoente(OldPX, OldPY, 3, VirusNoMundo));
                        Objeto.setCor(3); //Sera usado pra deletar o objeto e criar um novo.
                        MapaMundo[OldPY][OldPX] = Objeto.getCor();
                    break;
                    }
                }
            }

            if (Objeto.getCor() == 2 || Objeto.getCor() == 7) {
                int MoveRandom = new Random().nextInt(5) + 1;

                Objeto.Mover(MoveRandom);

                int NewPX = Objeto.getX();
                int NewPY = Objeto.getY();

                //Out of bounds
                Object[] GetClamps = ClampBounds(NewPX, NewPY);

                int ClampX = (int)GetClamps[1];
                int ClampY = (int)GetClamps[2];

                if ((boolean)GetClamps[0]) {
                    Objeto.setX(ClampX);
                    Objeto.setY(ClampY);                
                }

                int GetMapaCor = MapaMundo[ClampY][ClampX];

                Boolean IsInsideHP = GetMapaCor == 5 || GetMapaCor == 6;

                if (IsInsideHP) {
                    if (antiVirus.IniciarCura()) {
                        if (antiVirus.CuraTerminada()) {
                            Objeto.AplicarVacina(antiVirus.Vacina());
                        } else {
                            antiVirus.AjudarProgressoDaCura();
                        }
                    }
                }

                MapaMundo[ClampY][ClampX] = Objeto.getCor();
            }

        });         
    }

    /**
     * <p>Método onde {@link Classes.Humanos.PessoaDoente} é atualizado suas interações com o mundo</p>
     */ 
    protected void AtualizaPessoasDoentes() {
        PessoasDoentes.forEach(Objeto -> {
            int OldPX = Objeto.getX();
            int OldPY = Objeto.getY();

            MapaMundo[OldPY][OldPX] = 0;

            //verificar se esta no hospital

            //verificar se e zumbi

            int MoveRandom = new Random().nextInt((4 - 1) + 1) + 1;

            Objeto.Mover(MoveRandom);

            int NewPX = Objeto.getX();
            int NewPY = Objeto.getY();

            //Out of bounds
            Object[] GetClamps = ClampBounds(NewPX, NewPY);

            int ClampX = (int)GetClamps[1];
            int ClampY = (int)GetClamps[2];

            //Clamp was Trigged
            if ((boolean)GetClamps[0]) {
                Objeto.setX(ClampX);
                Objeto.setY(ClampY);                
            }

            int GetMapaCor = MapaMundo[ClampY][ClampX];


            //?Especial Functions

            if (Objeto.getIsZumbi()) {
                if (Objeto.getJaFoiZumbi()) {
                    NumeroDeZumbisMortos += 1;
                    Objeto.setCor(0);
                } else {
                    Zumbis.add(new Zumbi(ClampX, ClampY, 4, VirusNoMundo));
                    Objeto.setCor(4);
                }
            } else {

                Boolean IsInsideHP = GetMapaCor == 5 || GetMapaCor == 6;

                if (IsInsideHP) {
                    Objeto.setCor(2);
                    PessoasSaudaveis.add(new PessoaSaudavel(ClampX, ClampY, 2));
                }
            }
            
            //*Master Draw
            MapaMundo[ClampY][ClampX] = Objeto.getCor();

        });        
    }

    /**
     * <p>Método onde {@link Classes.Estrutura.Hospital} é atualizado suas interações com o mundo</p>
     */ 
    protected void AtualizaHospital() {
        //Last Draw (Fix hospital holes XD)
        Hospitais.forEach(Objeto -> {
            int[] SafePos = {Objeto.getSafePosX(), Objeto.getSafePosY()};

            //Safe Caught
            if (SafePos[0] == 0 || SafePos[1] == 0) {
                return;
            }

            int[][] GetHospital = Objeto.getEstruturaHospital();

            int SizeHPLinha = GetHospital.length;
            int SizeHPColuna = GetHospital[0].length;

            //Transcript {X,Y} > {X2, Y2}
            for (int i = 0; i < SizeHPLinha; i++) {
                for (int j = 0; j < SizeHPColuna; j++) {
                    int TransX = SafePos[0] + i;
                    int TransY = SafePos[1] + j;

                    int CheckCor = MapaMundo[TransX][TransY];
                    if (CheckCor == 0) {
                        MapaMundo[TransX][TransY] = GetHospital[i][j];
                    }
                }
            }
        });
    }

    //Atualiza movimentacao, infecta saudaveis, etc etc...
    //Processos (call order): PessoasSaudaveis, Zumbis, PessoasDoentes, PessoasDoentes, Hospitais

    public void atualizaMundo(){

        //Problema livre
        antiVirus.getQuantZumbis(Zumbis.size());
        //        
        
        AtualizaZumbis();
        AtualizaPessoasSaudaveis();
        AtualizaPessoasDoentes();

        //Remocoes por conversao
        PessoasDoentes.removeIf(Object -> Object.getCor() == 4 || Object.getCor() == 2 || Object.getCor() == 0);
        PessoasSaudaveis.removeIf(Object -> Object.getCor() == 3);
        Zumbis.removeIf(Object -> Object.getCor() == 3 || Object.getCor() == 0);

        AtualizaHospital();

        //Atualizar numeros
        setNumeroDeSaudaveis(PessoasSaudaveis.size());
        setNumeroDeDoentes(PessoasDoentes.size());
        setNumeroDeZumbis(Zumbis.size());
    }
    
    public void desenhaMundo(){
        for(int i = 0; i < MapaMundo.length; i ++){
            for(int j = 0; j < MapaMundo[i].length; j++){
                switch(MapaMundo[i][j]){
                    case 0 -> System.out.print(" ");
                    case 1 -> System.out.print("\033[45m \033[0m");  //! [Parede]   Magenta
                    case 2 -> System.out.print("\033[44m \033[0m"); //! [Saudavel] Azul
                    case 3 -> System.out.print("\033[43m \033[0m"); //! [Doente]   Amarelo
                    case 4 -> System.out.print("\033[42m \033[0m"); //! [Zumbi]    Verde
                    case 5 -> System.out.print("\033[41m \033[0m"); //! [Hospital] Vermelho
                    case 6 -> System.out.print("\033[47m \033[0m"); //! [Hospital] Branco   
                    case 7 -> System.out.print("\033[46m \033[0m"); //! [Curado]   Ciano                                                                    
                };
            };
           System.out.println();
        };
        System.out.println("\n\n");
    }

    //Problema livre
    public double getProgressoDaCuraMundial() {
        return antiVirus.getProgressoDaCura();
    }

    public boolean getCuraMundialTerminada() {
        return antiVirus.CuraTerminada();
    }

    /**
     * <p>Método onde é verificado quantas pessoas foram curadas</p>
     * @return Numero de pessoas Curadas
     */      
    int CacheCurados = 0;
    public int getCuradosMundial() {
        CacheCurados = 0;
        PessoasSaudaveis.forEach(Objeto -> {
            if (Objeto.getIsVacinado()) {
                CacheCurados+= 1;
            }
        });
        return CacheCurados;
    }

    public int getNumeroDeSaudaveis() {
        return NumeroDeSaudaveis;
    }

    /**
     * <p>Método exclusivo para a classe onde é atualizado o numero de pessoas saudaveis.</p>
     * @param numeroDeSaudaveis Número de pessoas saudaveis a ser colocado.
     */    
    protected void setNumeroDeSaudaveis(int numeroDeSaudaveis) {
        NumeroDeSaudaveis = numeroDeSaudaveis;
    }

    public int getNumeroDeDoentes() {
        return NumeroDeDoentes;
    }

    /**
     * <p>Método exclusivo para a classe onde é atualizado o numero de pessoas doentes.</p>
     * @param numeroDeDoentes Número de pessoas doentes a ser colocado.
     */     
    protected void setNumeroDeDoentes(int numeroDeDoentes) {
        NumeroDeDoentes = numeroDeDoentes;
    }

    public int getNumeroDeZumbis() {
        return NumeroDeZumbis;
    }

    /**
     * <p>Método exclusivo para a classe onde é atualizado o numero de zumbis.</p>
     * @param numeroDeZumbis Número de zumbis a ser colocado.
     */      
    protected void setNumeroDeZumbis(int numeroDeZumbis) {
        NumeroDeZumbis = numeroDeZumbis;
    }

    public int getNumeroDeZumbisCurados() {
        return NumeroDeZumbisCurados;
    }

    public int getNumeroDeZumbisMortos() {
        return NumeroDeZumbisMortos;
    }
}

