package Classes.Estrutura;

import java.util.Random;

/**
* Classe Hospital tera suas Cordenadas geradas aleatóriamente e para isso, Verificações complexas são executadas para que o programa não de erro na hora de executar. <br>
* <br> Toda a verificação é dinamica ou seja, o algoritimo irá pegar A estrutura do hospital e calcular uma cordenada utilizando a area determinada estaticamente.
* <br> Ao todo são usados 12 pontos de verificação para que o programa de uma coordenada valida respeitando a Area.
* <br> Caso uma coordenada é valida irá retornar para o mundo, do contrário irá tentar indefinidamente até achar uma.
* <br> <br> Limitações: <br> 
* <br> 1. Hospital precisa ser maior ou igual ao tamanho da area de verificação
* <br> 2. Area de verificação não pode ser a Metade do mundo em X e Y. 
* <br> 
* <br> A coordenada onde o Hospital irá ser gerado aleatoriamente e é determinado pelas Verificações explicadas a baixo. <br>
* Verificações: <br>
* <br> 0. Verificar se a cordenada é valida. (Evitar Parede, Calculando O tamanho do hospital)
* <br> 1. Verificar se ja tem um hospital na coordenada escolhida.
* <br> 2. Verificar se tem um hospital dentro da area DistanciaMinima (variavel)

* <br> 1 e 2 podem ser feitas usando um algoritimo.
*
* <br> Return -> Caso uma desses verificações derem negativo, faça o loop.
*/

public class Hospital {

    int SafePosX = 0;
    int SafePosY = 0;

    //Area -> 12x7
    protected int[][] EstruturaHospital = {
        {6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6},
        {6, 6, 6, 6, 6, 5, 5, 6, 6, 6, 6, 6},
        {6, 6, 6, 6, 6, 5, 5, 6, 6, 6, 6, 6},
        {6, 6, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6},
        {6, 6, 6, 6, 6, 5, 5, 6, 6, 6, 6, 6},
        {6, 6, 6, 6, 6, 5, 5, 6, 6, 6, 6, 6},
        {6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6},

    };    


    public int[][] getEstruturaHospital() {
        return EstruturaHospital;
    }

    int Linha, Coluna;
    int HospitalX = EstruturaHospital[0].length - 1;
    int HospitalY = EstruturaHospital.length - 1;

    int DistanciaMinimaV = 4; //Vertical
    int DistanciaMinimaH = 8; //Horizontal


    //! Verificações: 
    public int[] CriarHospital (int[][] Mundo) {
        
        int Linha = Mundo.length;
        int Coluna = Mundo[0].length;

        //Subtrair pelo --> (1 = Parede | 10 = Tamanho do hospital) => Verificar se o hospital vai ser gerado fora da area de jogo 

        int LinhaRandom = 0;
        int ColunaRandom = 0;

        //Fique gerando até achar um espaço para o hospital.
        boolean Gerador = true;
        while (Gerador) {
            try {
                Random random = new Random();
                LinhaRandom  = random.nextInt(((Coluna-(HospitalX+2)) - 2) + 1) + 2;
                ColunaRandom = random.nextInt(((Linha-(HospitalY+2))  - 2) + 1) + 2;

                //Clamps: Caso for gerado perto da parede direita, não deixe verificar out of bounds.

                //Clamp Formula = math.max(Minimo, math.min(Maximo, ValorParaClamp))

                int EsquerdaClampLinha = Math.max(1, Math.min(Coluna-2, LinhaRandom-DistanciaMinimaH));
                int DireitaClampLinha  = Math.max(1, Math.min(Coluna-2, LinhaRandom+HospitalX+DistanciaMinimaH));

                int CimaClampColuna  = Math.max(1, Math.min(Linha-2, ColunaRandom-DistanciaMinimaV));
                int BaixoClampColuna = Math.max(1, Math.min(Linha-2, ColunaRandom+HospitalY+DistanciaMinimaV));

                //Verificar distancia: Melhor algoritimo -> Verificar 4 pontos extremos do quadrado.

                int[][] PontosDeVerificao = {
                    {EsquerdaClampLinha, CimaClampColuna},  //Esqueda-Cima
                    {EsquerdaClampLinha, BaixoClampColuna}, //Esqueda-Baixo
                    {DireitaClampLinha, CimaClampColuna},   //Direita-Cima
                    {DireitaClampLinha, BaixoClampColuna},  //Direita-Baixa

                    //Meio

                    {(EsquerdaClampLinha+DireitaClampLinha)/2, CimaClampColuna}, //Cima

                    {EsquerdaClampLinha, (int)((CimaClampColuna+BaixoClampColuna)/3.5)},  //Esquerda-1
                    {EsquerdaClampLinha, (int)((CimaClampColuna+BaixoClampColuna)/2.0)},  //Esquerda-2
                    {EsquerdaClampLinha, (int)((CimaClampColuna+BaixoClampColuna)/1.3)},  //Esquerda-3

                    {(EsquerdaClampLinha+DireitaClampLinha)/2, BaixoClampColuna},  //Direita

                    {DireitaClampLinha, (int)((CimaClampColuna+BaixoClampColuna)/3.5)},  //Direita-1
                    {DireitaClampLinha, (int)((CimaClampColuna+BaixoClampColuna)/2.0)},  //Direita-2
                    {DireitaClampLinha, (int)((CimaClampColuna+BaixoClampColuna)/1.3)},  //Direita-3

                };

                //!DEBUG PONTO
                int[][] PontosDoHospital = {
                    {LinhaRandom, ColunaRandom}, //Esqueda-Cima
                    {LinhaRandom, ColunaRandom+HospitalY},  //Esqueda-Baixo
                    {LinhaRandom+HospitalX, ColunaRandom},  //Direita-Cima
                    {LinhaRandom+HospitalX, ColunaRandom+HospitalY},   //Direita-Baixa
                };

                ///////////////////////////////////////////

                //System.out.print(LinhaRandom + "[" + EsquerdaClampLinha +"]" + " _ " + ColunaRandom + "[" + CimaClampColuna +"]" + "\n");

        
                for (int i = 0; i < Linha; i++) {
                    for (int j = 0; j < Coluna; j++) {    
                        //boolean IsParede = (i == 0 || i == (Linha -1)) || (j == 0 || j == (Coluna-1)); 
                        
                        Boolean IsCheckArea = false;
                        for (int k = 0; k < PontosDeVerificao.length; k++) {

                            int PointX = PontosDeVerificao[k][1];
                            int PointY = PontosDeVerificao[k][0];

                            if (PointX == i && PointY == j) {
                                IsCheckArea = true;
                            } 
                        }

                        Boolean IsHospArea = false;
                        if (!IsCheckArea) {
                            for (int l = 0; l < PontosDoHospital.length; l++) {

                                int PointX = PontosDoHospital[l][1];
                                int PointY = PontosDoHospital[l][0];

                                if (PointX == i && PointY == j) {
                                    IsHospArea = true;
                                } 
                            }                        
                        }

                        if (IsCheckArea || IsHospArea) {
                            int CheckCor = Mundo[i][j];

                            //Verificar se tem um hospital no ponto de verificacao.
                            if (CheckCor == 5 || CheckCor == 6) {
                                throw new Exception("[WARNING] Reposicionando Hospital (Overlap Trigged)");
                            };
                        };
                        //System.out.print(IsParede ? 8 : (IsCheckArea ? 1 : (IsHospArea ? 5 :  "-")));
                    }
                    //System.out.print("\n");
                }
                Gerador = false;
            } catch (Exception e) {
                System.out.print(e.getMessage() + "\n");
            }
        };
        SafePosX = ColunaRandom;
        SafePosY = LinhaRandom;
        int[] SafeHPpos = {ColunaRandom, LinhaRandom};

        return SafeHPpos;
    }


    public int getSafePosX() {
        return SafePosX;
    }

    public int getSafePosY() {
        return SafePosY;
    }

}