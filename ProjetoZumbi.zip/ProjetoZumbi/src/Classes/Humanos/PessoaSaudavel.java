package Classes.Humanos;

import Classes.Interface.IMovable;

/**
* Classe Pessoa Saudavel possui o metodo {@link #PertoDeCotaminado()} onde retorna uma Array de todas as cordenadas adjacentes a partir da sua posição atual, para verificar se possui uma {@link PessoaDoente} ou {@link Zumbi}.
* <br> Também possui Metodos do problema livre como {@link #getIsVacinado()}, onde será imune a qualquer contato com {@link PessoaDoente} ou {@link Zumbi}.
*/
public class PessoaSaudavel extends Pessoa implements IMovable{
    private boolean IsVacinado = false;
    

    public boolean getIsVacinado() {
        return IsVacinado;
    }

    public PessoaSaudavel(int x, int y, int cor) {
        super(x, y, cor);
    }


    public int[][] PertoDeCotaminado() {
        //ATECAO: x = coluna ; y = linha
        //Definido por: PosCurrent, FindInfect{PosCima, PosBaixo, PosDireita, PosEsquerda}
        
        int GetX = getX();
        int GetY = getY();

        int[] PosCurrent = {GetX, GetY};

        int[][] FindInfected = {
            PosCurrent,
            {GetX, GetY-1}, //Cima
            {GetX, GetY+1}, //Baixo
            {GetX+1, GetY}, //Direita
            {GetX-1, GetY}  //Esquerda
        };


        return FindInfected;
    }

    public void AplicarVacina(int CorDaVacina) {
        IsVacinado = true;
        setCor(CorDaVacina);
    }

    @Override
    public void Mover(int Imove) {
        if (Imove == 1) {

            setY(getY() - 1);
        } else if (Imove == 2) {

            setY(getY() + 1);
        } else if (Imove == 3) {

            setX(getX() + 1);
        } else if (Imove == 4) {

            setX(getX() - 1);
        }
    }  
    
}
