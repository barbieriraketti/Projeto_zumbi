package Classes.Humanos;

import Classes.Virus.Virus;

/**
* Classe Zumbi tem o método onde verifica {@link #PertoDeVacinado()} onde retorna uma Array de todas as cordenadas adjacentes a partir da sua posição atual.
*/
public class Zumbi extends PessoaDoente {

    public Zumbi(int x, int y, int cor, Virus VirusNaPessoa) {
        super(x, y, cor, VirusNaPessoa);
    }
    
    public int[][] PertoDeVacinado() {
        //ATENCAO: x = coluna ; y = linha
        //Definido por: PosCurrent, FindInfect{PosCima, PosBaixo, PosDireita, PosEsquerda}
        
        int GetX = getX();
        int GetY = getY();

        int[] PosCurrent = {GetX, GetY};

        int[][] FindVacinado = {
            PosCurrent,
            {GetX, GetY-1}, //Cima
            {GetX, GetY+1}, //Baixo
            {GetX+1, GetY}, //Direita
            {GetX-1, GetY}  //Esquerda
        };


        return FindVacinado;
    }

}
